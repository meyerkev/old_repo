/*******************************************************************************
 * Copyright (c) 2003, 2006 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.ui.internal.navigator.actions;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IPartListener;
import org.eclipse.ui.IPropertyListener;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.internal.navigator.CommonNavigatorMessages;
import org.eclipse.ui.internal.navigator.NavigatorContentService;
import org.eclipse.ui.internal.navigator.NavigatorPlugin;
import org.eclipse.ui.internal.navigator.extensions.LinkHelperService;
import org.eclipse.ui.navigator.CommonNavigator;
import org.eclipse.ui.navigator.CommonViewer;
import org.eclipse.ui.navigator.ILinkHelper;
import org.eclipse.ui.navigator.INavigatorContentService;
import org.eclipse.ui.part.ISetSelectionTarget;
import org.eclipse.ui.progress.UIJob;

/**
 * This action links the activate editor with the Navigator selection.
 * 
 * @since 3.2
 */
public class LinkEditorAction extends Action implements
		ISelectionChangedListener, IAction, IPropertyListener {

	private static final long BRIEF_DELAY = 100;

	private IPartListener partListener;

	private final CommonNavigator commonNavigator;

	private final CommonViewer commonViewer;

	private final NavigatorContentService contentService;

	private final LinkHelperService linkService;

	private UIJob activateEditorJob = new UIJob(
			CommonNavigatorMessages.Link_With_Editor_Job_) {
		public IStatus runInUIThread(IProgressMonitor monitor) {

			ISelection selection = commonViewer.getSelection();
			if (selection != null && !selection.isEmpty()
					&& selection instanceof IStructuredSelection) {

				IStructuredSelection sSelection = (IStructuredSelection) selection;
				if (sSelection.size() == 1) {
					ILinkHelper[] helpers = linkService
							.getLinkHelpersFor(sSelection.getFirstElement());
					if (helpers.length > 0) {
						helpers[0].activateEditor(commonNavigator.getSite()
								.getPage(), sSelection);
					}
				}
			}
			return Status.OK_STATUS;
		}
	};
	

	private UIJob updateSelectionJob = new UIJob(
			CommonNavigatorMessages.Link_With_Editor_Job_) {
		public IStatus runInUIThread(IProgressMonitor monitor) {

			try { 
				IWorkbenchPage page = commonNavigator.getSite().getPage();
				if(page != null) {
					IEditorPart editor = page.getActiveEditor();
					if(editor != null) {
						IEditorInput input = editor.getEditorInput();
						ILinkHelper[] helpers = linkService.getLinkHelpersFor(input);
		
						IStructuredSelection selection = StructuredSelection.EMPTY;
						IStructuredSelection newSelection = StructuredSelection.EMPTY;
		
						for (int i = 0; i < helpers.length; i++) {
							selection = helpers[i].findSelection(input);
							if (selection != null && !selection.isEmpty()) {
								newSelection = mergeSelection(newSelection, selection);
							}
						}
						if(!newSelection.isEmpty()) {
							commonNavigator.selectReveal(newSelection);
						}
					}
				}
			} catch (Throwable e) { 
				String msg = e.getMessage() != null ? e.getMessage() : e.toString();
				NavigatorPlugin.logError(0, msg, e);
			}
			return Status.OK_STATUS;
		}
	};


	/**
	 * Create a LinkEditorAction for the given navigator and viewer.
	 * 
	 * @param aNavigator
	 *            The navigator which defines whether linking is enabled and
	 *            implements {@link ISetSelectionTarget}.
	 * @param aViewer
	 *            The common viewer instance with a
	 *            {@link INavigatorContentService}.
	 */
	public LinkEditorAction(CommonNavigator aNavigator, CommonViewer aViewer) {
		super(CommonNavigatorMessages.LinkEditorActionDelegate_0);
		setToolTipText(CommonNavigatorMessages.LinkEditorActionDelegate_1);
		commonNavigator = aNavigator;
		commonViewer = aViewer;
		contentService = (NavigatorContentService) aViewer
				.getNavigatorContentService();

		linkService = new LinkHelperService(contentService);

		init();
	}

	/**
	 * @see org.eclipse.ui.IViewActionDelegate#init(org.eclipse.ui.IViewPart)
	 */
	protected void init() {
		partListener = new IPartListener() {

			public void partActivated(IWorkbenchPart part) {
				if (part instanceof IEditorPart) {
					updateSelectionJob.schedule(BRIEF_DELAY);
				}
			}

			public void partBroughtToTop(IWorkbenchPart part) {
				if (part instanceof IEditorPart) {
					updateSelectionJob.schedule(BRIEF_DELAY);
				}
			}

			public void partClosed(IWorkbenchPart part) {

			}

			public void partDeactivated(IWorkbenchPart part) {
			}

			public void partOpened(IWorkbenchPart part) {
			}
		};

		updateLinkingEnabled(commonNavigator.isLinkingEnabled());

		commonNavigator.addPropertyListener(this);

		// linkHelperRegistry = new
		// LinkHelperManager(commonViewer.getNavigatorContentService());
	}

	/**
	 * 
	 */
	public void dispose() {
		commonNavigator.removePropertyListener(this);
		if (isChecked()) {
			commonViewer.removePostSelectionChangedListener(this);
			commonNavigator.getSite().getPage()
					.removePartListener(partListener);
		}

	}

	/**
	 * @see org.eclipse.ui.IActionDelegate#run(org.eclipse.jface.action.IAction)
	 */
	public void run() {
		commonNavigator.setLinkingEnabled(!commonNavigator.isLinkingEnabled());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.jface.viewers.ISelectionChangedList 
	 */
	public void selectionChanged(SelectionChangedEvent event) {
		if (commonNavigator.isLinkingEnabled()) {
			activateEditor();
		}

	}

	/**
	 * Update the active editor based on the current selection in the Navigator.
	 */
	protected void activateEditor() {
		ISelection selection = commonViewer.getSelection();
		if (selection != null && !selection.isEmpty()
				&& selection instanceof IStructuredSelection) { 
			/*
			 * Create and schedule a UI Job to activate the editor in a valid
			 * Display thread
			 */
			activateEditorJob.schedule(BRIEF_DELAY);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.ui.IPropertyListener#propertyChanged(java.lang.Object,
	 *      int)
	 */
	public void propertyChanged(Object aSource, int aPropertyId) {
		switch (aPropertyId) {
		case CommonNavigator.IS_LINKING_ENABLED_PROPERTY:
			updateLinkingEnabled(((CommonNavigator) aSource).isLinkingEnabled());
		}
	}

	/**
	 * @param toEnableLinking
	 */
	private void updateLinkingEnabled(boolean toEnableLinking) {
		setChecked(toEnableLinking);

		if (toEnableLinking) {
			
			updateSelectionJob.schedule(BRIEF_DELAY);

			commonViewer.addPostSelectionChangedListener(this);
			commonNavigator.getSite().getPage().addPartListener(partListener);
		} else {
			commonViewer.removePostSelectionChangedListener(this);
			commonNavigator.getSite().getPage()
					.removePartListener(partListener);
		}
	}

	private IStructuredSelection mergeSelection(IStructuredSelection aBase,
			IStructuredSelection aSelectionToAppend) {
		if (aBase == null || aBase.isEmpty()) {
			return (aSelectionToAppend != null) ? aSelectionToAppend
					: StructuredSelection.EMPTY;
		} else if (aSelectionToAppend == null || aSelectionToAppend.isEmpty()) {
			return aBase;
		} else {
			List newItems = new ArrayList(aBase.toList());
			newItems.addAll(aSelectionToAppend.toList());
			return new StructuredSelection(newItems);
		}
	} 

}
